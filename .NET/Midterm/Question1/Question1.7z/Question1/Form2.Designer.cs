﻿namespace Question1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            button17 = new Button();
            button18 = new Button();
            button15 = new Button();
            button16 = new Button();
            button13 = new Button();
            button14 = new Button();
            button11 = new Button();
            button12 = new Button();
            button9 = new Button();
            button10 = new Button();
            button7 = new Button();
            button8 = new Button();
            button5 = new Button();
            button6 = new Button();
            button4 = new Button();
            button3 = new Button();
            label8 = new Label();
            pictureBox9 = new PictureBox();
            label9 = new Label();
            pictureBox10 = new PictureBox();
            label10 = new Label();
            pictureBox11 = new PictureBox();
            label5 = new Label();
            pictureBox6 = new PictureBox();
            label4 = new Label();
            pictureBox5 = new PictureBox();
            label3 = new Label();
            pictureBox4 = new PictureBox();
            label2 = new Label();
            pictureBox3 = new PictureBox();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button24 = new Button();
            button25 = new Button();
            button26 = new Button();
            button27 = new Button();
            button28 = new Button();
            button29 = new Button();
            button30 = new Button();
            button31 = new Button();
            button32 = new Button();
            button33 = new Button();
            button34 = new Button();
            button35 = new Button();
            label6 = new Label();
            pictureBox7 = new PictureBox();
            label7 = new Label();
            pictureBox8 = new PictureBox();
            label11 = new Label();
            pictureBox12 = new PictureBox();
            label12 = new Label();
            pictureBox13 = new PictureBox();
            label13 = new Label();
            pictureBox14 = new PictureBox();
            label14 = new Label();
            pictureBox15 = new PictureBox();
            label15 = new Label();
            pictureBox16 = new PictureBox();
            label16 = new Label();
            pictureBox17 = new PictureBox();
            button1 = new Button();
            button2 = new Button();
            pictureBox2 = new PictureBox();
            button23 = new Button();
            textBox1 = new TextBox();
            listView1 = new ListView();
            button36 = new Button();
            comboBox1 = new ComboBox();
            button37 = new Button();
            panel3 = new Panel();
            button39 = new Button();
            button40 = new Button();
            button41 = new Button();
            button42 = new Button();
            button43 = new Button();
            button44 = new Button();
            button45 = new Button();
            button46 = new Button();
            button47 = new Button();
            button48 = new Button();
            button49 = new Button();
            button50 = new Button();
            button51 = new Button();
            button52 = new Button();
            button53 = new Button();
            button54 = new Button();
            label17 = new Label();
            pictureBox18 = new PictureBox();
            label18 = new Label();
            pictureBox19 = new PictureBox();
            label19 = new Label();
            pictureBox20 = new PictureBox();
            label20 = new Label();
            pictureBox21 = new PictureBox();
            label21 = new Label();
            pictureBox22 = new PictureBox();
            label22 = new Label();
            pictureBox23 = new PictureBox();
            label23 = new Label();
            pictureBox24 = new PictureBox();
            label24 = new Label();
            pictureBox25 = new PictureBox();
            panel4 = new Panel();
            button55 = new Button();
            button56 = new Button();
            button57 = new Button();
            button58 = new Button();
            button59 = new Button();
            button60 = new Button();
            button61 = new Button();
            button62 = new Button();
            button63 = new Button();
            button64 = new Button();
            button65 = new Button();
            button66 = new Button();
            button67 = new Button();
            button68 = new Button();
            button69 = new Button();
            button70 = new Button();
            label25 = new Label();
            pictureBox26 = new PictureBox();
            label26 = new Label();
            pictureBox27 = new PictureBox();
            label27 = new Label();
            pictureBox28 = new PictureBox();
            label28 = new Label();
            pictureBox29 = new PictureBox();
            label29 = new Label();
            pictureBox30 = new PictureBox();
            label30 = new Label();
            pictureBox31 = new PictureBox();
            label31 = new Label();
            pictureBox32 = new PictureBox();
            label32 = new Label();
            pictureBox33 = new PictureBox();
            label33 = new Label();
            button38 = new Button();
            menuStrip1 = new MenuStrip();
            menuToolStripMenuItem = new ToolStripMenuItem();
            aboutUsToolStripMenuItem = new ToolStripMenuItem();
            toolStripSeparator1 = new ToolStripSeparator();
            logoutToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox23).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox24).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox26).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox27).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox28).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox29).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox30).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox31).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox32).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox33).BeginInit();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ScrollBar;
            panel1.Controls.Add(button17);
            panel1.Controls.Add(button18);
            panel1.Controls.Add(button15);
            panel1.Controls.Add(button16);
            panel1.Controls.Add(button13);
            panel1.Controls.Add(button14);
            panel1.Controls.Add(button11);
            panel1.Controls.Add(button12);
            panel1.Controls.Add(button9);
            panel1.Controls.Add(button10);
            panel1.Controls.Add(button7);
            panel1.Controls.Add(button8);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(button6);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(pictureBox9);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(pictureBox10);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(pictureBox11);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(pictureBox6);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(pictureBox5);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(12, 112);
            panel1.Name = "panel1";
            panel1.Size = new Size(705, 482);
            panel1.TabIndex = 0;
            // 
            // button17
            // 
            button17.Location = new Point(638, 443);
            button17.Name = "button17";
            button17.Size = new Size(23, 23);
            button17.TabIndex = 63;
            button17.Text = "-";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button17_Click;
            // 
            // button18
            // 
            button18.Location = new Point(667, 443);
            button18.Name = "button18";
            button18.Size = new Size(23, 23);
            button18.TabIndex = 62;
            button18.Text = "+";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button18_Click;
            // 
            // button15
            // 
            button15.Location = new Point(462, 443);
            button15.Name = "button15";
            button15.Size = new Size(23, 23);
            button15.TabIndex = 61;
            button15.Text = "-";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button15_Click;
            // 
            // button16
            // 
            button16.Location = new Point(491, 443);
            button16.Name = "button16";
            button16.Size = new Size(23, 23);
            button16.TabIndex = 60;
            button16.Text = "+";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button16_Click;
            // 
            // button13
            // 
            button13.Location = new Point(286, 443);
            button13.Name = "button13";
            button13.Size = new Size(23, 23);
            button13.TabIndex = 59;
            button13.Text = "-";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.Location = new Point(315, 443);
            button14.Name = "button14";
            button14.Size = new Size(23, 23);
            button14.TabIndex = 58;
            button14.Text = "+";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button14_Click;
            // 
            // button11
            // 
            button11.Location = new Point(111, 443);
            button11.Name = "button11";
            button11.Size = new Size(23, 23);
            button11.TabIndex = 57;
            button11.Text = "-";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.Location = new Point(140, 443);
            button12.Name = "button12";
            button12.Size = new Size(23, 23);
            button12.TabIndex = 56;
            button12.Text = "+";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click_1;
            // 
            // button9
            // 
            button9.Location = new Point(638, 202);
            button9.Name = "button9";
            button9.Size = new Size(23, 23);
            button9.TabIndex = 55;
            button9.Text = "-";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(667, 202);
            button10.Name = "button10";
            button10.Size = new Size(23, 23);
            button10.TabIndex = 54;
            button10.Text = "+";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button7
            // 
            button7.Location = new Point(462, 202);
            button7.Name = "button7";
            button7.Size = new Size(23, 23);
            button7.TabIndex = 53;
            button7.Text = "-";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(491, 202);
            button8.Name = "button8";
            button8.Size = new Size(23, 23);
            button8.TabIndex = 52;
            button8.Text = "+";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button5
            // 
            button5.Location = new Point(286, 202);
            button5.Name = "button5";
            button5.Size = new Size(23, 23);
            button5.TabIndex = 51;
            button5.Text = "-";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(315, 202);
            button6.Name = "button6";
            button6.Size = new Size(23, 23);
            button6.TabIndex = 50;
            button6.Text = "+";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button4
            // 
            button4.Location = new Point(111, 202);
            button4.Name = "button4";
            button4.Size = new Size(23, 23);
            button4.TabIndex = 49;
            button4.Text = "-";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.Location = new Point(140, 202);
            button3.Name = "button3";
            button3.Size = new Size(23, 23);
            button3.TabIndex = 48;
            button3.Text = "+";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label8
            // 
            label8.BackColor = Color.AliceBlue;
            label8.BorderStyle = BorderStyle.FixedSingle;
            label8.Font = new Font("Segoe UI", 9F);
            label8.Location = new Point(364, 395);
            label8.Name = "label8";
            label8.Size = new Size(150, 45);
            label8.TabIndex = 37;
            label8.Text = "EVGA 700W PSU\r\n$84.99";
            label8.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox9
            // 
            pictureBox9.BackColor = Color.White;
            pictureBox9.BorderStyle = BorderStyle.FixedSingle;
            pictureBox9.Image = Properties.Resources._17_438_159_V09;
            pictureBox9.Location = new Point(364, 242);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(150, 150);
            pictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox9.TabIndex = 35;
            pictureBox9.TabStop = false;
            // 
            // label9
            // 
            label9.BackColor = Color.AliceBlue;
            label9.BorderStyle = BorderStyle.FixedSingle;
            label9.Font = new Font("Segoe UI", 9F);
            label9.Location = new Point(188, 395);
            label9.Name = "label9";
            label9.Size = new Size(150, 45);
            label9.TabIndex = 32;
            label9.Text = "NZXT Kraken RGB 280mm\r\n$189.99";
            label9.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox10
            // 
            pictureBox10.BackColor = Color.White;
            pictureBox10.BorderStyle = BorderStyle.FixedSingle;
            pictureBox10.Image = Properties.Resources._35_146_124_01;
            pictureBox10.Location = new Point(188, 242);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(150, 150);
            pictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox10.TabIndex = 30;
            pictureBox10.TabStop = false;
            // 
            // label10
            // 
            label10.BackColor = Color.AliceBlue;
            label10.BorderStyle = BorderStyle.FixedSingle;
            label10.Font = new Font("Segoe UI", 9F);
            label10.Location = new Point(13, 395);
            label10.Name = "label10";
            label10.Size = new Size(150, 45);
            label10.TabIndex = 27;
            label10.Text = "AMD Ryzen 5 7600\r\n$269.00";
            label10.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = Color.White;
            pictureBox11.BorderStyle = BorderStyle.FixedSingle;
            pictureBox11.Image = Properties.Resources._19_113_787_03;
            pictureBox11.Location = new Point(13, 242);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(150, 150);
            pictureBox11.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox11.TabIndex = 25;
            pictureBox11.TabStop = false;
            // 
            // label5
            // 
            label5.BackColor = Color.AliceBlue;
            label5.BorderStyle = BorderStyle.FixedSingle;
            label5.Font = new Font("Segoe UI", 9F);
            label5.Location = new Point(540, 154);
            label5.Name = "label5";
            label5.Size = new Size(150, 45);
            label5.TabIndex = 22;
            label5.Text = "WD Blue M.2 1TB SSD\r\n$89.97";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.White;
            pictureBox6.BorderStyle = BorderStyle.FixedSingle;
            pictureBox6.Image = Properties.Resources._20_250_254_01;
            pictureBox6.Location = new Point(540, 1);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(150, 150);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 20;
            pictureBox6.TabStop = false;
            // 
            // label4
            // 
            label4.BackColor = Color.AliceBlue;
            label4.BorderStyle = BorderStyle.FixedSingle;
            label4.Font = new Font("Segoe UI", 9F);
            label4.Location = new Point(540, 395);
            label4.Name = "label4";
            label4.Size = new Size(150, 45);
            label4.TabIndex = 17;
            label4.Text = "Intel Core i5-12600KF\r\n$219.99";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.White;
            pictureBox5.BorderStyle = BorderStyle.FixedSingle;
            pictureBox5.Image = Properties.Resources._19_118_349_05;
            pictureBox5.Location = new Point(540, 242);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(150, 150);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 15;
            pictureBox5.TabStop = false;
            // 
            // label3
            // 
            label3.BackColor = Color.AliceBlue;
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("Segoe UI", 9F);
            label3.Location = new Point(364, 154);
            label3.Name = "label3";
            label3.Size = new Size(150, 45);
            label3.TabIndex = 12;
            label3.Text = "Gigabyte GeForce 4070\r\n$749.99";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.White;
            pictureBox4.BorderStyle = BorderStyle.FixedSingle;
            pictureBox4.Image = Properties.Resources._14_932_611_V01;
            pictureBox4.Location = new Point(364, 1);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(150, 150);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 10;
            pictureBox4.TabStop = false;
            // 
            // label2
            // 
            label2.BackColor = Color.AliceBlue;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Segoe UI", 9F);
            label2.Location = new Point(188, 154);
            label2.Name = "label2";
            label2.Size = new Size(150, 45);
            label2.TabIndex = 7;
            label2.Text = "Hasee Z8 Gaming Laptop\r\n$1099.99";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.White;
            pictureBox3.BorderStyle = BorderStyle.FixedSingle;
            pictureBox3.Image = Properties.Resources.BDT0S2304270RJ8UO52;
            pictureBox3.Location = new Point(188, 1);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(150, 150);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 5;
            pictureBox3.TabStop = false;
            // 
            // label1
            // 
            label1.BackColor = Color.AliceBlue;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 9F);
            label1.Location = new Point(13, 154);
            label1.Name = "label1";
            label1.Size = new Size(150, 45);
            label1.TabIndex = 2;
            label1.Text = "Yeyian Yumi Gaming PC\r\n$1099.99";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.White;
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Image = Properties.Resources._3D5_002P_00044_081;
            pictureBox1.Location = new Point(13, 1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(150, 150);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ScrollBar;
            panel2.Controls.Add(button19);
            panel2.Controls.Add(button20);
            panel2.Controls.Add(button21);
            panel2.Controls.Add(button22);
            panel2.Controls.Add(button24);
            panel2.Controls.Add(button25);
            panel2.Controls.Add(button26);
            panel2.Controls.Add(button27);
            panel2.Controls.Add(button28);
            panel2.Controls.Add(button29);
            panel2.Controls.Add(button30);
            panel2.Controls.Add(button31);
            panel2.Controls.Add(button32);
            panel2.Controls.Add(button33);
            panel2.Controls.Add(button34);
            panel2.Controls.Add(button35);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(pictureBox7);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(pictureBox8);
            panel2.Controls.Add(label11);
            panel2.Controls.Add(pictureBox12);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(pictureBox13);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(pictureBox14);
            panel2.Controls.Add(label14);
            panel2.Controls.Add(pictureBox15);
            panel2.Controls.Add(label15);
            panel2.Controls.Add(pictureBox16);
            panel2.Controls.Add(label16);
            panel2.Controls.Add(pictureBox17);
            panel2.Location = new Point(12, 112);
            panel2.Name = "panel2";
            panel2.Size = new Size(705, 482);
            panel2.TabIndex = 64;
            panel2.Visible = false;
            // 
            // button19
            // 
            button19.Location = new Point(638, 443);
            button19.Name = "button19";
            button19.Size = new Size(23, 23);
            button19.TabIndex = 63;
            button19.Text = "-";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // button20
            // 
            button20.Location = new Point(667, 443);
            button20.Name = "button20";
            button20.Size = new Size(23, 23);
            button20.TabIndex = 62;
            button20.Text = "+";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button20_Click;
            // 
            // button21
            // 
            button21.Location = new Point(462, 443);
            button21.Name = "button21";
            button21.Size = new Size(23, 23);
            button21.TabIndex = 61;
            button21.Text = "-";
            button21.UseVisualStyleBackColor = true;
            button21.Click += button21_Click;
            // 
            // button22
            // 
            button22.Location = new Point(491, 443);
            button22.Name = "button22";
            button22.Size = new Size(23, 23);
            button22.TabIndex = 60;
            button22.Text = "+";
            button22.UseVisualStyleBackColor = true;
            button22.Click += button22_Click;
            // 
            // button24
            // 
            button24.Location = new Point(286, 443);
            button24.Name = "button24";
            button24.Size = new Size(23, 23);
            button24.TabIndex = 59;
            button24.Text = "-";
            button24.UseVisualStyleBackColor = true;
            button24.Click += button24_Click;
            // 
            // button25
            // 
            button25.Location = new Point(315, 443);
            button25.Name = "button25";
            button25.Size = new Size(23, 23);
            button25.TabIndex = 58;
            button25.Text = "+";
            button25.UseVisualStyleBackColor = true;
            button25.Click += button25_Click;
            // 
            // button26
            // 
            button26.Location = new Point(111, 443);
            button26.Name = "button26";
            button26.Size = new Size(23, 23);
            button26.TabIndex = 57;
            button26.Text = "-";
            button26.UseVisualStyleBackColor = true;
            button26.Click += button26_Click;
            // 
            // button27
            // 
            button27.Location = new Point(140, 443);
            button27.Name = "button27";
            button27.Size = new Size(23, 23);
            button27.TabIndex = 56;
            button27.Text = "+";
            button27.UseVisualStyleBackColor = true;
            button27.Click += button27_Click;
            // 
            // button28
            // 
            button28.Location = new Point(638, 202);
            button28.Name = "button28";
            button28.Size = new Size(23, 23);
            button28.TabIndex = 55;
            button28.Text = "-";
            button28.UseVisualStyleBackColor = true;
            button28.Click += button28_Click;
            // 
            // button29
            // 
            button29.Location = new Point(667, 202);
            button29.Name = "button29";
            button29.Size = new Size(23, 23);
            button29.TabIndex = 54;
            button29.Text = "+";
            button29.UseVisualStyleBackColor = true;
            button29.Click += button29_Click;
            // 
            // button30
            // 
            button30.Location = new Point(462, 202);
            button30.Name = "button30";
            button30.Size = new Size(23, 23);
            button30.TabIndex = 53;
            button30.Text = "-";
            button30.UseVisualStyleBackColor = true;
            button30.Click += button30_Click;
            // 
            // button31
            // 
            button31.Location = new Point(491, 202);
            button31.Name = "button31";
            button31.Size = new Size(23, 23);
            button31.TabIndex = 52;
            button31.Text = "+";
            button31.UseVisualStyleBackColor = true;
            button31.Click += button31_Click;
            // 
            // button32
            // 
            button32.Location = new Point(286, 202);
            button32.Name = "button32";
            button32.Size = new Size(23, 23);
            button32.TabIndex = 51;
            button32.Text = "-";
            button32.UseVisualStyleBackColor = true;
            button32.Click += button32_Click;
            // 
            // button33
            // 
            button33.Location = new Point(315, 202);
            button33.Name = "button33";
            button33.Size = new Size(23, 23);
            button33.TabIndex = 50;
            button33.Text = "+";
            button33.UseVisualStyleBackColor = true;
            button33.Click += button33_Click;
            // 
            // button34
            // 
            button34.Location = new Point(111, 202);
            button34.Name = "button34";
            button34.Size = new Size(23, 23);
            button34.TabIndex = 49;
            button34.Text = "-";
            button34.UseVisualStyleBackColor = true;
            button34.Click += button34_Click;
            // 
            // button35
            // 
            button35.Location = new Point(140, 202);
            button35.Name = "button35";
            button35.Size = new Size(23, 23);
            button35.TabIndex = 48;
            button35.Text = "+";
            button35.UseVisualStyleBackColor = true;
            button35.Click += button35_Click;
            // 
            // label6
            // 
            label6.BackColor = Color.AliceBlue;
            label6.BorderStyle = BorderStyle.FixedSingle;
            label6.Font = new Font("Segoe UI", 9F);
            label6.Location = new Point(364, 395);
            label6.Name = "label6";
            label6.Size = new Size(150, 45);
            label6.TabIndex = 37;
            label6.Text = "ASRock B550 Phantom\r\n$699.99";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.White;
            pictureBox7.BorderStyle = BorderStyle.FixedSingle;
            pictureBox7.Image = Properties.Resources._13_157_949_V80;
            pictureBox7.Location = new Point(364, 242);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(150, 150);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 35;
            pictureBox7.TabStop = false;
            // 
            // label7
            // 
            label7.BackColor = Color.AliceBlue;
            label7.BorderStyle = BorderStyle.FixedSingle;
            label7.Font = new Font("Segoe UI", 9F);
            label7.Location = new Point(188, 395);
            label7.Name = "label7";
            label7.Size = new Size(150, 45);
            label7.TabIndex = 32;
            label7.Text = "GIGABYTE Z790\r\n$283.99";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.White;
            pictureBox8.BorderStyle = BorderStyle.FixedSingle;
            pictureBox8.Image = Properties.Resources._13_145_480_V02;
            pictureBox8.Location = new Point(188, 242);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(150, 150);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 30;
            pictureBox8.TabStop = false;
            // 
            // label11
            // 
            label11.BackColor = Color.AliceBlue;
            label11.BorderStyle = BorderStyle.FixedSingle;
            label11.Font = new Font("Segoe UI", 9F);
            label11.Location = new Point(13, 395);
            label11.Name = "label11";
            label11.Size = new Size(150, 45);
            label11.TabIndex = 27;
            label11.Text = "SAMA SM68 Wireless\r\n$35.99";
            label11.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox12
            // 
            pictureBox12.BackColor = Color.White;
            pictureBox12.BorderStyle = BorderStyle.FixedSingle;
            pictureBox12.Image = Properties.Resources.B41TS2407040KEITM56;
            pictureBox12.Location = new Point(13, 242);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(150, 150);
            pictureBox12.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox12.TabIndex = 25;
            pictureBox12.TabStop = false;
            // 
            // label12
            // 
            label12.BackColor = Color.AliceBlue;
            label12.BorderStyle = BorderStyle.FixedSingle;
            label12.Font = new Font("Segoe UI", 9F);
            label12.Location = new Point(540, 154);
            label12.Name = "label12";
            label12.Size = new Size(150, 45);
            label12.TabIndex = 22;
            label12.Text = "ASUS TUF B760-PLUS\r\n$188.99";
            label12.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox13
            // 
            pictureBox13.BackColor = Color.White;
            pictureBox13.BorderStyle = BorderStyle.FixedSingle;
            pictureBox13.Image = Properties.Resources._13_119_641_03;
            pictureBox13.Location = new Point(540, 1);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(150, 150);
            pictureBox13.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox13.TabIndex = 20;
            pictureBox13.TabStop = false;
            // 
            // label13
            // 
            label13.BackColor = Color.AliceBlue;
            label13.BorderStyle = BorderStyle.FixedSingle;
            label13.Font = new Font("Segoe UI", 9F);
            label13.Location = new Point(540, 395);
            label13.Name = "label13";
            label13.Size = new Size(150, 45);
            label13.TabIndex = 17;
            label13.Text = "SAMA 6CF1201\r\n$15.99";
            label13.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox14
            // 
            pictureBox14.BackColor = Color.White;
            pictureBox14.BorderStyle = BorderStyle.FixedSingle;
            pictureBox14.Image = Properties.Resources.B41TS24042708QJTVD3;
            pictureBox14.Location = new Point(540, 242);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(150, 150);
            pictureBox14.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox14.TabIndex = 15;
            pictureBox14.TabStop = false;
            // 
            // label14
            // 
            label14.BackColor = Color.AliceBlue;
            label14.BorderStyle = BorderStyle.FixedSingle;
            label14.Font = new Font("Segoe UI", 9F);
            label14.Location = new Point(364, 154);
            label14.Name = "label14";
            label14.Size = new Size(150, 45);
            label14.TabIndex = 12;
            label14.Text = "LIAN LI 011 EVO\r\n$189.99";
            label14.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox15
            // 
            pictureBox15.BackColor = Color.White;
            pictureBox15.BorderStyle = BorderStyle.FixedSingle;
            pictureBox15.Image = Properties.Resources.AFSTS2312155IHaQ;
            pictureBox15.Location = new Point(364, 1);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new Size(150, 150);
            pictureBox15.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox15.TabIndex = 10;
            pictureBox15.TabStop = false;
            // 
            // label15
            // 
            label15.BackColor = Color.AliceBlue;
            label15.BorderStyle = BorderStyle.FixedSingle;
            label15.Font = new Font("Segoe UI", 9F);
            label15.Location = new Point(188, 154);
            label15.Name = "label15";
            label15.Size = new Size(150, 45);
            label15.TabIndex = 7;
            label15.Text = "KingSpec 2TB NVMe\r\n$203.99";
            label15.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox16
            // 
            pictureBox16.BackColor = Color.White;
            pictureBox16.BorderStyle = BorderStyle.FixedSingle;
            pictureBox16.Image = Properties.Resources.B1V8S2310100DOHBMC4;
            pictureBox16.Location = new Point(188, 1);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new Size(150, 150);
            pictureBox16.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox16.TabIndex = 5;
            pictureBox16.TabStop = false;
            // 
            // label16
            // 
            label16.BackColor = Color.AliceBlue;
            label16.BorderStyle = BorderStyle.FixedSingle;
            label16.Font = new Font("Segoe UI", 9F);
            label16.Location = new Point(13, 154);
            label16.Name = "label16";
            label16.Size = new Size(150, 45);
            label16.TabIndex = 2;
            label16.Text = "Yeyian PHOENIX GLASS\r\n$2,299.97";
            label16.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox17
            // 
            pictureBox17.BackColor = Color.White;
            pictureBox17.BorderStyle = BorderStyle.FixedSingle;
            pictureBox17.Image = Properties.Resources._83_630_051_06;
            pictureBox17.Location = new Point(13, 1);
            pictureBox17.Name = "pictureBox17";
            pictureBox17.Size = new Size(150, 150);
            pictureBox17.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox17.TabIndex = 0;
            pictureBox17.TabStop = false;
            // 
            // button1
            // 
            button1.Location = new Point(759, 52);
            button1.Name = "button1";
            button1.Size = new Size(75, 51);
            button1.TabIndex = 1;
            button1.Text = "<<";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(840, 52);
            button2.Name = "button2";
            button2.Size = new Size(75, 51);
            button2.TabIndex = 2;
            button2.Text = ">>";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = SystemColors.Highlight;
            pictureBox2.Location = new Point(12, 39);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(705, 64);
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            // 
            // button23
            // 
            button23.Font = new Font("Segoe UI", 14F);
            button23.Location = new Point(723, 112);
            button23.Name = "button23";
            button23.Size = new Size(226, 40);
            button23.TabIndex = 4;
            button23.Text = "Computers";
            button23.UseVisualStyleBackColor = true;
            button23.Click += button23_Click;
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.Window;
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.Location = new Point(723, 512);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(226, 23);
            textBox1.TabIndex = 6;
            textBox1.Text = "Total:";
            // 
            // listView1
            // 
            listView1.BorderStyle = BorderStyle.FixedSingle;
            listView1.Location = new Point(723, 204);
            listView1.Name = "listView1";
            listView1.Size = new Size(226, 273);
            listView1.TabIndex = 7;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            listView1.SelectedIndexChanged += listView1_SelectedIndexChanged;
            // 
            // button36
            // 
            button36.Location = new Point(786, 541);
            button36.Name = "button36";
            button36.Size = new Size(163, 53);
            button36.TabIndex = 65;
            button36.Text = "Checkout";
            button36.UseVisualStyleBackColor = true;
            button36.Click += button36_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "5%", "10%", "15%", "25%", "50%", "75%" });
            comboBox1.Location = new Point(723, 483);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(226, 23);
            comboBox1.TabIndex = 66;
            comboBox1.Text = "Discount";
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // button37
            // 
            button37.Font = new Font("Segoe UI", 14F);
            button37.Location = new Point(723, 158);
            button37.Name = "button37";
            button37.Size = new Size(226, 40);
            button37.TabIndex = 67;
            button37.Text = "Video Games";
            button37.UseVisualStyleBackColor = true;
            button37.Click += button37_Click_1;
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ScrollBar;
            panel3.Controls.Add(button39);
            panel3.Controls.Add(button40);
            panel3.Controls.Add(button41);
            panel3.Controls.Add(button42);
            panel3.Controls.Add(button43);
            panel3.Controls.Add(button44);
            panel3.Controls.Add(button45);
            panel3.Controls.Add(button46);
            panel3.Controls.Add(button47);
            panel3.Controls.Add(button48);
            panel3.Controls.Add(button49);
            panel3.Controls.Add(button50);
            panel3.Controls.Add(button51);
            panel3.Controls.Add(button52);
            panel3.Controls.Add(button53);
            panel3.Controls.Add(button54);
            panel3.Controls.Add(label17);
            panel3.Controls.Add(pictureBox18);
            panel3.Controls.Add(label18);
            panel3.Controls.Add(pictureBox19);
            panel3.Controls.Add(label19);
            panel3.Controls.Add(pictureBox20);
            panel3.Controls.Add(label20);
            panel3.Controls.Add(pictureBox21);
            panel3.Controls.Add(label21);
            panel3.Controls.Add(pictureBox22);
            panel3.Controls.Add(label22);
            panel3.Controls.Add(pictureBox23);
            panel3.Controls.Add(label23);
            panel3.Controls.Add(pictureBox24);
            panel3.Controls.Add(label24);
            panel3.Controls.Add(pictureBox25);
            panel3.Location = new Point(12, 112);
            panel3.Name = "panel3";
            panel3.Size = new Size(705, 482);
            panel3.TabIndex = 65;
            panel3.Visible = false;
            // 
            // button39
            // 
            button39.Location = new Point(638, 443);
            button39.Name = "button39";
            button39.Size = new Size(23, 23);
            button39.TabIndex = 63;
            button39.Text = "-";
            button39.UseVisualStyleBackColor = true;
            button39.Click += button39_Click;
            // 
            // button40
            // 
            button40.Location = new Point(667, 443);
            button40.Name = "button40";
            button40.Size = new Size(23, 23);
            button40.TabIndex = 62;
            button40.Text = "+";
            button40.UseVisualStyleBackColor = true;
            button40.Click += button40_Click;
            // 
            // button41
            // 
            button41.Location = new Point(462, 443);
            button41.Name = "button41";
            button41.Size = new Size(23, 23);
            button41.TabIndex = 61;
            button41.Text = "-";
            button41.UseVisualStyleBackColor = true;
            button41.Click += button41_Click;
            // 
            // button42
            // 
            button42.Location = new Point(491, 443);
            button42.Name = "button42";
            button42.Size = new Size(23, 23);
            button42.TabIndex = 60;
            button42.Text = "+";
            button42.UseVisualStyleBackColor = true;
            button42.Click += button42_Click;
            // 
            // button43
            // 
            button43.Location = new Point(286, 443);
            button43.Name = "button43";
            button43.Size = new Size(23, 23);
            button43.TabIndex = 59;
            button43.Text = "-";
            button43.UseVisualStyleBackColor = true;
            button43.Click += button43_Click;
            // 
            // button44
            // 
            button44.Location = new Point(315, 443);
            button44.Name = "button44";
            button44.Size = new Size(23, 23);
            button44.TabIndex = 58;
            button44.Text = "+";
            button44.UseVisualStyleBackColor = true;
            button44.Click += button44_Click;
            // 
            // button45
            // 
            button45.Location = new Point(111, 443);
            button45.Name = "button45";
            button45.Size = new Size(23, 23);
            button45.TabIndex = 57;
            button45.Text = "-";
            button45.UseVisualStyleBackColor = true;
            button45.Click += button45_Click;
            // 
            // button46
            // 
            button46.Location = new Point(140, 443);
            button46.Name = "button46";
            button46.Size = new Size(23, 23);
            button46.TabIndex = 56;
            button46.Text = "+";
            button46.UseVisualStyleBackColor = true;
            button46.Click += button46_Click;
            // 
            // button47
            // 
            button47.Location = new Point(638, 202);
            button47.Name = "button47";
            button47.Size = new Size(23, 23);
            button47.TabIndex = 55;
            button47.Text = "-";
            button47.UseVisualStyleBackColor = true;
            button47.Click += button47_Click;
            // 
            // button48
            // 
            button48.Location = new Point(667, 202);
            button48.Name = "button48";
            button48.Size = new Size(23, 23);
            button48.TabIndex = 54;
            button48.Text = "+";
            button48.UseVisualStyleBackColor = true;
            button48.Click += button48_Click;
            // 
            // button49
            // 
            button49.Location = new Point(462, 202);
            button49.Name = "button49";
            button49.Size = new Size(23, 23);
            button49.TabIndex = 53;
            button49.Text = "-";
            button49.UseVisualStyleBackColor = true;
            button49.Click += button49_Click;
            // 
            // button50
            // 
            button50.Location = new Point(491, 202);
            button50.Name = "button50";
            button50.Size = new Size(23, 23);
            button50.TabIndex = 52;
            button50.Text = "+";
            button50.UseVisualStyleBackColor = true;
            button50.Click += button50_Click;
            // 
            // button51
            // 
            button51.Location = new Point(286, 202);
            button51.Name = "button51";
            button51.Size = new Size(23, 23);
            button51.TabIndex = 51;
            button51.Text = "-";
            button51.UseVisualStyleBackColor = true;
            button51.Click += button51_Click;
            // 
            // button52
            // 
            button52.Location = new Point(315, 202);
            button52.Name = "button52";
            button52.Size = new Size(23, 23);
            button52.TabIndex = 50;
            button52.Text = "+";
            button52.UseVisualStyleBackColor = true;
            button52.Click += button52_Click;
            // 
            // button53
            // 
            button53.Location = new Point(111, 202);
            button53.Name = "button53";
            button53.Size = new Size(23, 23);
            button53.TabIndex = 49;
            button53.Text = "-";
            button53.UseVisualStyleBackColor = true;
            button53.Click += button53_Click;
            // 
            // button54
            // 
            button54.Location = new Point(140, 202);
            button54.Name = "button54";
            button54.Size = new Size(23, 23);
            button54.TabIndex = 48;
            button54.Text = "+";
            button54.UseVisualStyleBackColor = true;
            button54.Click += button54_Click;
            // 
            // label17
            // 
            label17.BackColor = Color.AliceBlue;
            label17.BorderStyle = BorderStyle.FixedSingle;
            label17.Font = new Font("Segoe UI", 9F);
            label17.Location = new Point(364, 395);
            label17.Name = "label17";
            label17.Size = new Size(150, 45);
            label17.TabIndex = 37;
            label17.Text = "Nocturnal\r\n$49.99";
            label17.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox18
            // 
            pictureBox18.BackColor = Color.White;
            pictureBox18.BorderStyle = BorderStyle.FixedSingle;
            pictureBox18.Image = Properties.Resources._2med__6_;
            pictureBox18.Location = new Point(364, 242);
            pictureBox18.Name = "pictureBox18";
            pictureBox18.Size = new Size(150, 150);
            pictureBox18.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox18.TabIndex = 35;
            pictureBox18.TabStop = false;
            // 
            // label18
            // 
            label18.BackColor = Color.AliceBlue;
            label18.BorderStyle = BorderStyle.FixedSingle;
            label18.Font = new Font("Segoe UI", 9F);
            label18.Location = new Point(188, 395);
            label18.Name = "label18";
            label18.Size = new Size(150, 45);
            label18.TabIndex = 32;
            label18.Text = "Silent Hill 2\r\n$89.99";
            label18.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox19
            // 
            pictureBox19.BackColor = Color.White;
            pictureBox19.BorderStyle = BorderStyle.FixedSingle;
            pictureBox19.Image = Properties.Resources._2med__5_;
            pictureBox19.Location = new Point(188, 242);
            pictureBox19.Name = "pictureBox19";
            pictureBox19.Size = new Size(150, 150);
            pictureBox19.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox19.TabIndex = 30;
            pictureBox19.TabStop = false;
            // 
            // label19
            // 
            label19.BackColor = Color.AliceBlue;
            label19.BorderStyle = BorderStyle.FixedSingle;
            label19.Font = new Font("Segoe UI", 9F);
            label19.Location = new Point(13, 395);
            label19.Name = "label19";
            label19.Size = new Size(150, 45);
            label19.TabIndex = 27;
            label19.Text = "Star Wars: Outlaws\r\n$79.99";
            label19.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox20
            // 
            pictureBox20.BackColor = Color.White;
            pictureBox20.BorderStyle = BorderStyle.FixedSingle;
            pictureBox20.Image = Properties.Resources._2med__4_;
            pictureBox20.Location = new Point(13, 242);
            pictureBox20.Name = "pictureBox20";
            pictureBox20.Size = new Size(150, 150);
            pictureBox20.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox20.TabIndex = 25;
            pictureBox20.TabStop = false;
            // 
            // label20
            // 
            label20.BackColor = Color.AliceBlue;
            label20.BorderStyle = BorderStyle.FixedSingle;
            label20.Font = new Font("Segoe UI", 9F);
            label20.Location = new Point(540, 154);
            label20.Name = "label20";
            label20.Size = new Size(150, 45);
            label20.TabIndex = 22;
            label20.Text = "Zelda: Echoes of Wisdom\r\n$79.99";
            label20.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox21
            // 
            pictureBox21.BackColor = Color.White;
            pictureBox21.BorderStyle = BorderStyle.FixedSingle;
            pictureBox21.Image = Properties.Resources._2med__3_;
            pictureBox21.Location = new Point(540, 1);
            pictureBox21.Name = "pictureBox21";
            pictureBox21.Size = new Size(150, 150);
            pictureBox21.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox21.TabIndex = 20;
            pictureBox21.TabStop = false;
            // 
            // label21
            // 
            label21.BackColor = Color.AliceBlue;
            label21.BorderStyle = BorderStyle.FixedSingle;
            label21.Font = new Font("Segoe UI", 9F);
            label21.Location = new Point(540, 395);
            label21.Name = "label21";
            label21.Size = new Size(150, 45);
            label21.TabIndex = 17;
            label21.Text = "Little Nightmares III\r\n$54.99";
            label21.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox22
            // 
            pictureBox22.BackColor = Color.White;
            pictureBox22.BorderStyle = BorderStyle.FixedSingle;
            pictureBox22.Image = Properties.Resources._2med__7_;
            pictureBox22.Location = new Point(540, 242);
            pictureBox22.Name = "pictureBox22";
            pictureBox22.Size = new Size(150, 150);
            pictureBox22.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox22.TabIndex = 15;
            pictureBox22.TabStop = false;
            // 
            // label22
            // 
            label22.BackColor = Color.AliceBlue;
            label22.BorderStyle = BorderStyle.FixedSingle;
            label22.Font = new Font("Segoe UI", 9F);
            label22.Location = new Point(364, 154);
            label22.Name = "label22";
            label22.Size = new Size(150, 45);
            label22.TabIndex = 12;
            label22.Text = "COD Black Ops 6\r\n$89.99";
            label22.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox23
            // 
            pictureBox23.BackColor = Color.White;
            pictureBox23.BorderStyle = BorderStyle.FixedSingle;
            pictureBox23.Image = Properties.Resources._2med__2_;
            pictureBox23.Location = new Point(364, 1);
            pictureBox23.Name = "pictureBox23";
            pictureBox23.Size = new Size(150, 150);
            pictureBox23.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox23.TabIndex = 10;
            pictureBox23.TabStop = false;
            // 
            // label23
            // 
            label23.BackColor = Color.AliceBlue;
            label23.BorderStyle = BorderStyle.FixedSingle;
            label23.Font = new Font("Segoe UI", 9F);
            label23.Location = new Point(188, 154);
            label23.Name = "label23";
            label23.Size = new Size(150, 45);
            label23.TabIndex = 7;
            label23.Text = "Mario Party Jamboree\r\n$79.99";
            label23.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox24
            // 
            pictureBox24.BackColor = Color.White;
            pictureBox24.BorderStyle = BorderStyle.FixedSingle;
            pictureBox24.Image = Properties.Resources._2med__1_;
            pictureBox24.Location = new Point(188, 1);
            pictureBox24.Name = "pictureBox24";
            pictureBox24.Size = new Size(150, 150);
            pictureBox24.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox24.TabIndex = 5;
            pictureBox24.TabStop = false;
            // 
            // label24
            // 
            label24.BackColor = Color.AliceBlue;
            label24.BorderStyle = BorderStyle.FixedSingle;
            label24.Font = new Font("Segoe UI", 9F);
            label24.Location = new Point(13, 154);
            label24.Name = "label24";
            label24.Size = new Size(150, 45);
            label24.TabIndex = 2;
            label24.Text = "Astro Bot\r\n$79.99";
            label24.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox25
            // 
            pictureBox25.BackColor = Color.White;
            pictureBox25.BorderStyle = BorderStyle.FixedSingle;
            pictureBox25.Image = Properties.Resources._2med;
            pictureBox25.Location = new Point(13, 1);
            pictureBox25.Name = "pictureBox25";
            pictureBox25.Size = new Size(150, 150);
            pictureBox25.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox25.TabIndex = 0;
            pictureBox25.TabStop = false;
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.ScrollBar;
            panel4.Controls.Add(button55);
            panel4.Controls.Add(button56);
            panel4.Controls.Add(button57);
            panel4.Controls.Add(button58);
            panel4.Controls.Add(button59);
            panel4.Controls.Add(button60);
            panel4.Controls.Add(button61);
            panel4.Controls.Add(button62);
            panel4.Controls.Add(button63);
            panel4.Controls.Add(button64);
            panel4.Controls.Add(button65);
            panel4.Controls.Add(button66);
            panel4.Controls.Add(button67);
            panel4.Controls.Add(button68);
            panel4.Controls.Add(button69);
            panel4.Controls.Add(button70);
            panel4.Controls.Add(label25);
            panel4.Controls.Add(pictureBox26);
            panel4.Controls.Add(label26);
            panel4.Controls.Add(pictureBox27);
            panel4.Controls.Add(label27);
            panel4.Controls.Add(pictureBox28);
            panel4.Controls.Add(label28);
            panel4.Controls.Add(pictureBox29);
            panel4.Controls.Add(label29);
            panel4.Controls.Add(pictureBox30);
            panel4.Controls.Add(label30);
            panel4.Controls.Add(pictureBox31);
            panel4.Controls.Add(label31);
            panel4.Controls.Add(pictureBox32);
            panel4.Controls.Add(label32);
            panel4.Controls.Add(pictureBox33);
            panel4.Location = new Point(12, 112);
            panel4.Name = "panel4";
            panel4.Size = new Size(705, 482);
            panel4.TabIndex = 66;
            panel4.Visible = false;
            panel4.Paint += panel4_Paint;
            // 
            // button55
            // 
            button55.Location = new Point(638, 443);
            button55.Name = "button55";
            button55.Size = new Size(23, 23);
            button55.TabIndex = 63;
            button55.Text = "-";
            button55.UseVisualStyleBackColor = true;
            button55.Click += button55_Click;
            // 
            // button56
            // 
            button56.Location = new Point(667, 443);
            button56.Name = "button56";
            button56.Size = new Size(23, 23);
            button56.TabIndex = 62;
            button56.Text = "+";
            button56.UseVisualStyleBackColor = true;
            button56.Click += button56_Click;
            // 
            // button57
            // 
            button57.Location = new Point(462, 443);
            button57.Name = "button57";
            button57.Size = new Size(23, 23);
            button57.TabIndex = 61;
            button57.Text = "-";
            button57.UseVisualStyleBackColor = true;
            button57.Click += button57_Click;
            // 
            // button58
            // 
            button58.Location = new Point(491, 443);
            button58.Name = "button58";
            button58.Size = new Size(23, 23);
            button58.TabIndex = 60;
            button58.Text = "+";
            button58.UseVisualStyleBackColor = true;
            button58.Click += button58_Click;
            // 
            // button59
            // 
            button59.Location = new Point(286, 443);
            button59.Name = "button59";
            button59.Size = new Size(23, 23);
            button59.TabIndex = 59;
            button59.Text = "-";
            button59.UseVisualStyleBackColor = true;
            button59.Click += button59_Click;
            // 
            // button60
            // 
            button60.Location = new Point(315, 443);
            button60.Name = "button60";
            button60.Size = new Size(23, 23);
            button60.TabIndex = 58;
            button60.Text = "+";
            button60.UseVisualStyleBackColor = true;
            button60.Click += button60_Click;
            // 
            // button61
            // 
            button61.Location = new Point(111, 443);
            button61.Name = "button61";
            button61.Size = new Size(23, 23);
            button61.TabIndex = 57;
            button61.Text = "-";
            button61.UseVisualStyleBackColor = true;
            button61.Click += button61_Click;
            // 
            // button62
            // 
            button62.Location = new Point(140, 443);
            button62.Name = "button62";
            button62.Size = new Size(23, 23);
            button62.TabIndex = 56;
            button62.Text = "+";
            button62.UseVisualStyleBackColor = true;
            button62.Click += button62_Click;
            // 
            // button63
            // 
            button63.Location = new Point(638, 202);
            button63.Name = "button63";
            button63.Size = new Size(23, 23);
            button63.TabIndex = 55;
            button63.Text = "-";
            button63.UseVisualStyleBackColor = true;
            button63.Click += button63_Click;
            // 
            // button64
            // 
            button64.Location = new Point(667, 202);
            button64.Name = "button64";
            button64.Size = new Size(23, 23);
            button64.TabIndex = 54;
            button64.Text = "+";
            button64.UseVisualStyleBackColor = true;
            button64.Click += button64_Click;
            // 
            // button65
            // 
            button65.Location = new Point(462, 202);
            button65.Name = "button65";
            button65.Size = new Size(23, 23);
            button65.TabIndex = 53;
            button65.Text = "-";
            button65.UseVisualStyleBackColor = true;
            button65.Click += button65_Click;
            // 
            // button66
            // 
            button66.Location = new Point(491, 202);
            button66.Name = "button66";
            button66.Size = new Size(23, 23);
            button66.TabIndex = 52;
            button66.Text = "+";
            button66.UseVisualStyleBackColor = true;
            button66.Click += button66_Click;
            // 
            // button67
            // 
            button67.Location = new Point(286, 202);
            button67.Name = "button67";
            button67.Size = new Size(23, 23);
            button67.TabIndex = 51;
            button67.Text = "-";
            button67.UseVisualStyleBackColor = true;
            button67.Click += button67_Click;
            // 
            // button68
            // 
            button68.Location = new Point(315, 202);
            button68.Name = "button68";
            button68.Size = new Size(23, 23);
            button68.TabIndex = 50;
            button68.Text = "+";
            button68.UseVisualStyleBackColor = true;
            button68.Click += button68_Click;
            // 
            // button69
            // 
            button69.Location = new Point(111, 202);
            button69.Name = "button69";
            button69.Size = new Size(23, 23);
            button69.TabIndex = 49;
            button69.Text = "-";
            button69.UseVisualStyleBackColor = true;
            button69.Click += button69_Click;
            // 
            // button70
            // 
            button70.Location = new Point(140, 202);
            button70.Name = "button70";
            button70.Size = new Size(23, 23);
            button70.TabIndex = 48;
            button70.Text = "+";
            button70.UseVisualStyleBackColor = true;
            button70.Click += button70_Click;
            // 
            // label25
            // 
            label25.BackColor = Color.AliceBlue;
            label25.BorderStyle = BorderStyle.FixedSingle;
            label25.Font = new Font("Segoe UI", 9F);
            label25.Location = new Point(364, 395);
            label25.Name = "label25";
            label25.Size = new Size(150, 45);
            label25.TabIndex = 37;
            label25.Text = "Undisputed\r\n$79.99";
            label25.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox26
            // 
            pictureBox26.BackColor = Color.White;
            pictureBox26.BorderStyle = BorderStyle.FixedSingle;
            pictureBox26.Image = Properties.Resources._2med__14_;
            pictureBox26.Location = new Point(364, 242);
            pictureBox26.Name = "pictureBox26";
            pictureBox26.Size = new Size(150, 150);
            pictureBox26.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox26.TabIndex = 35;
            pictureBox26.TabStop = false;
            // 
            // label26
            // 
            label26.BackColor = Color.AliceBlue;
            label26.BorderStyle = BorderStyle.FixedSingle;
            label26.Font = new Font("Segoe UI", 9F);
            label26.Location = new Point(188, 395);
            label26.Name = "label26";
            label26.Size = new Size(150, 45);
            label26.TabIndex = 32;
            label26.Text = "Goblin Slayer\r\n$69.99";
            label26.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox27
            // 
            pictureBox27.BackColor = Color.White;
            pictureBox27.BorderStyle = BorderStyle.FixedSingle;
            pictureBox27.Image = Properties.Resources._2med__13_;
            pictureBox27.Location = new Point(188, 242);
            pictureBox27.Name = "pictureBox27";
            pictureBox27.Size = new Size(150, 150);
            pictureBox27.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox27.TabIndex = 30;
            pictureBox27.TabStop = false;
            // 
            // label27
            // 
            label27.BackColor = Color.AliceBlue;
            label27.BorderStyle = BorderStyle.FixedSingle;
            label27.Font = new Font("Segoe UI", 9F);
            label27.Location = new Point(13, 395);
            label27.Name = "label27";
            label27.Size = new Size(150, 45);
            label27.TabIndex = 27;
            label27.Text = "Petit Island\r\n$79.99";
            label27.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox28
            // 
            pictureBox28.BackColor = Color.White;
            pictureBox28.BorderStyle = BorderStyle.FixedSingle;
            pictureBox28.Image = Properties.Resources._2med__12_;
            pictureBox28.Location = new Point(13, 242);
            pictureBox28.Name = "pictureBox28";
            pictureBox28.Size = new Size(150, 150);
            pictureBox28.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox28.TabIndex = 25;
            pictureBox28.TabStop = false;
            // 
            // label28
            // 
            label28.BackColor = Color.AliceBlue;
            label28.BorderStyle = BorderStyle.FixedSingle;
            label28.Font = new Font("Segoe UI", 9F);
            label28.Location = new Point(540, 154);
            label28.Name = "label28";
            label28.Size = new Size(150, 45);
            label28.TabIndex = 22;
            label28.Text = "Indiana Jones\r\n$89.99";
            label28.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox29
            // 
            pictureBox29.BackColor = Color.White;
            pictureBox29.BorderStyle = BorderStyle.FixedSingle;
            pictureBox29.Image = Properties.Resources._2med__11_;
            pictureBox29.Location = new Point(540, 1);
            pictureBox29.Name = "pictureBox29";
            pictureBox29.Size = new Size(150, 150);
            pictureBox29.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox29.TabIndex = 20;
            pictureBox29.TabStop = false;
            // 
            // label29
            // 
            label29.BackColor = Color.AliceBlue;
            label29.BorderStyle = BorderStyle.FixedSingle;
            label29.Font = new Font("Segoe UI", 9F);
            label29.Location = new Point(540, 395);
            label29.Name = "label29";
            label29.Size = new Size(150, 45);
            label29.TabIndex = 17;
            label29.Text = "Battle Of Rebels\r\n$49.99";
            label29.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox30
            // 
            pictureBox30.BackColor = Color.White;
            pictureBox30.BorderStyle = BorderStyle.FixedSingle;
            pictureBox30.Image = Properties.Resources._2med__15_;
            pictureBox30.Location = new Point(540, 242);
            pictureBox30.Name = "pictureBox30";
            pictureBox30.Size = new Size(150, 150);
            pictureBox30.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox30.TabIndex = 15;
            pictureBox30.TabStop = false;
            // 
            // label30
            // 
            label30.BackColor = Color.AliceBlue;
            label30.BorderStyle = BorderStyle.FixedSingle;
            label30.Font = new Font("Segoe UI", 9F);
            label30.Location = new Point(364, 154);
            label30.Name = "label30";
            label30.Size = new Size(150, 45);
            label30.TabIndex = 12;
            label30.Text = "Ravenswatch\r\n$49.99";
            label30.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox31
            // 
            pictureBox31.BackColor = Color.White;
            pictureBox31.BorderStyle = BorderStyle.FixedSingle;
            pictureBox31.Image = Properties.Resources._2med__10_;
            pictureBox31.Location = new Point(364, 1);
            pictureBox31.Name = "pictureBox31";
            pictureBox31.Size = new Size(150, 150);
            pictureBox31.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox31.TabIndex = 10;
            pictureBox31.TabStop = false;
            // 
            // label31
            // 
            label31.BackColor = Color.AliceBlue;
            label31.BorderStyle = BorderStyle.FixedSingle;
            label31.Font = new Font("Segoe UI", 9F);
            label31.Location = new Point(188, 154);
            label31.Name = "label31";
            label31.Size = new Size(150, 45);
            label31.TabIndex = 7;
            label31.Text = "Orange Season\r\n$39.99";
            label31.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox32
            // 
            pictureBox32.BackColor = Color.White;
            pictureBox32.BorderStyle = BorderStyle.FixedSingle;
            pictureBox32.Image = Properties.Resources._2med__9_;
            pictureBox32.Location = new Point(188, 1);
            pictureBox32.Name = "pictureBox32";
            pictureBox32.Size = new Size(150, 150);
            pictureBox32.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox32.TabIndex = 5;
            pictureBox32.TabStop = false;
            // 
            // label32
            // 
            label32.BackColor = Color.AliceBlue;
            label32.BorderStyle = BorderStyle.FixedSingle;
            label32.Font = new Font("Segoe UI", 9F);
            label32.Location = new Point(13, 154);
            label32.Name = "label32";
            label32.Size = new Size(150, 45);
            label32.TabIndex = 2;
            label32.Text = "Titan Quest II\r\n$69.99";
            label32.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox33
            // 
            pictureBox33.BackColor = Color.White;
            pictureBox33.BorderStyle = BorderStyle.FixedSingle;
            pictureBox33.Image = Properties.Resources._2med__8_;
            pictureBox33.Location = new Point(13, 1);
            pictureBox33.Name = "pictureBox33";
            pictureBox33.Size = new Size(150, 150);
            pictureBox33.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox33.TabIndex = 0;
            pictureBox33.TabStop = false;
            // 
            // label33
            // 
            label33.BackColor = SystemColors.MenuHighlight;
            label33.Font = new Font("Segoe UI Black", 32.25F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label33.ForeColor = SystemColors.Control;
            label33.Location = new Point(12, 39);
            label33.Name = "label33";
            label33.Size = new Size(705, 64);
            label33.TabIndex = 68;
            label33.Text = "Averyzon";
            label33.TextAlign = ContentAlignment.TopCenter;
            // 
            // button38
            // 
            button38.Location = new Point(723, 541);
            button38.Name = "button38";
            button38.Size = new Size(57, 53);
            button38.TabIndex = 69;
            button38.Text = "Reset";
            button38.UseVisualStyleBackColor = true;
            button38.Click += button38_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { menuToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(958, 24);
            menuStrip1.TabIndex = 70;
            menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            menuToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { aboutUsToolStripMenuItem, toolStripSeparator1, logoutToolStripMenuItem, exitToolStripMenuItem });
            menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            menuToolStripMenuItem.Size = new Size(50, 20);
            menuToolStripMenuItem.Text = "Menu";
            // 
            // aboutUsToolStripMenuItem
            // 
            aboutUsToolStripMenuItem.Name = "aboutUsToolStripMenuItem";
            aboutUsToolStripMenuItem.Size = new Size(123, 22);
            aboutUsToolStripMenuItem.Text = "About Us";
            aboutUsToolStripMenuItem.Click += aboutUsToolStripMenuItem_Click;
            // 
            // toolStripSeparator1
            // 
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new Size(120, 6);
            // 
            // logoutToolStripMenuItem
            // 
            logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            logoutToolStripMenuItem.Size = new Size(123, 22);
            logoutToolStripMenuItem.Text = "Logout";
            logoutToolStripMenuItem.Click += logoutToolStripMenuItem_Click;
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(123, 22);
            exitToolStripMenuItem.Text = "Exit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(958, 609);
            Controls.Add(button38);
            Controls.Add(label33);
            Controls.Add(button37);
            Controls.Add(comboBox1);
            Controls.Add(button36);
            Controls.Add(listView1);
            Controls.Add(textBox1);
            Controls.Add(button23);
            Controls.Add(pictureBox2);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(menuStrip1);
            Controls.Add(panel1);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            MainMenuStrip = menuStrip1;
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox21).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox22).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox23).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox24).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox25).EndInit();
            panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox26).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox27).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox28).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox29).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox30).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox31).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox32).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox33).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button button1;
        private Button button2;
        private PictureBox pictureBox1;
        private Label label1;
        private PictureBox pictureBox2;
        private Label label8;
        private PictureBox pictureBox9;
        private Label label9;
        private PictureBox pictureBox10;
        private Label label10;
        private PictureBox pictureBox11;
        private Label label5;
        private PictureBox pictureBox6;
        private Label label4;
        private PictureBox pictureBox5;
        private Label label3;
        private PictureBox pictureBox4;
        private Label label2;
        private PictureBox pictureBox3;
        private Button button23;
        private Button button4;
        private Button button3;
        private TextBox textBox1;
        private ListView listView1;
        private Button button7;
        private Button button8;
        private Button button5;
        private Button button6;
        private Button button9;
        private Button button10;
        private Button button17;
        private Button button18;
        private Button button15;
        private Button button16;
        private Button button13;
        private Button button14;
        private Button button11;
        private Button button12;
        private Panel panel2;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button24;
        private Button button25;
        private Button button26;
        private Button button27;
        private Button button28;
        private Button button29;
        private Button button30;
        private Button button31;
        private Button button32;
        private Button button33;
        private Button button34;
        private Button button35;
        private Label label6;
        private PictureBox pictureBox7;
        private Label label7;
        private PictureBox pictureBox8;
        private Label label11;
        private PictureBox pictureBox12;
        private Label label12;
        private PictureBox pictureBox13;
        private Label label13;
        private PictureBox pictureBox14;
        private Label label14;
        private PictureBox pictureBox15;
        private Label label15;
        private PictureBox pictureBox16;
        private Label label16;
        private PictureBox pictureBox17;
        private Button button36;
        private ComboBox comboBox1;
        private Button button37;
        private Panel panel3;
        private Button button39;
        private Button button40;
        private Button button41;
        private Button button42;
        private Button button43;
        private Button button44;
        private Button button45;
        private Button button46;
        private Button button47;
        private Button button48;
        private Button button49;
        private Button button50;
        private Button button51;
        private Button button52;
        private Button button53;
        private Button button54;
        private Label label17;
        private PictureBox pictureBox18;
        private Label label18;
        private PictureBox pictureBox19;
        private Label label19;
        private PictureBox pictureBox20;
        private Label label20;
        private PictureBox pictureBox21;
        private Label label21;
        private PictureBox pictureBox22;
        private Label label22;
        private PictureBox pictureBox23;
        private Label label23;
        private PictureBox pictureBox24;
        private Label label24;
        private PictureBox pictureBox25;
        private Panel panel4;
        private Button button55;
        private Button button56;
        private Button button57;
        private Button button58;
        private Button button59;
        private Button button60;
        private Button button61;
        private Button button62;
        private Button button63;
        private Button button64;
        private Button button65;
        private Button button66;
        private Button button67;
        private Button button68;
        private Button button69;
        private Button button70;
        private Label label25;
        private PictureBox pictureBox26;
        private Label label26;
        private PictureBox pictureBox27;
        private Label label27;
        private PictureBox pictureBox28;
        private Label label28;
        private PictureBox pictureBox29;
        private Label label29;
        private PictureBox pictureBox30;
        private Label label30;
        private PictureBox pictureBox31;
        private Label label31;
        private PictureBox pictureBox32;
        private Label label32;
        private PictureBox pictureBox33;
        private Label label33;
        private Button button38;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem menuToolStripMenuItem;
        private ToolStripMenuItem aboutUsToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem logoutToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
    }
}